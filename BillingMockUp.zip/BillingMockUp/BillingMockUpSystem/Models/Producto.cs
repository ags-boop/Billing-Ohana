﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace BillingMockUpSystem.Models
{
    public partial class Producto
    {
        public int Id { get; set; }
        public decimal? Medida { get; set; }
        public string Marca { get; set; }
        public int Cantidad { get; set; }
        public decimal? Unitario { get; set; }
        public decimal? Bulto { get; set; }
        public string Etiqueta { get; set; }
    }
}
