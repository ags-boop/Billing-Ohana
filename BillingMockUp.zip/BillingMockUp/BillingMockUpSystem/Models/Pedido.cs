﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BillingMockUpSystem.Models
{
    public partial class Pedido
    {
        public int Id { get; set; }
        public decimal? Medida { get; set; }
        public string Tipo { get; set; }
        public decimal? Unitario { get; set; }
        public decimal? Bulto { get; set; }
        public decimal? Total { get; set; }
    }
}
